# AI-based-Natural-disaster-analysis

Dataset Link :https://drive.google.com/drive/folders/1OUWjDeAAq00O5JcylVGw9NIWdF3qLTTC
